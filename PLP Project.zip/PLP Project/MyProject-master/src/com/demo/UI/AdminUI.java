package com.demo.UI;

import com.demo.Model.User;
import com.demo.Service.Implementation.AdminServiceImplementation;
import com.demo.Util.IRSValues;

import java.util.ArrayList;

public class AdminUI {

    // =========================================================
    // =                                                       =
    // =           1. When User Logged In As Admin             =
    // =                                                       =
    // =========================================================

      static void loginAsAdmin(User loggedInUser) {
        StartUI.printSymbols();
        StartUI.greetUser(loggedInUser);

        System.out.println("Please Press 1 To Add User");
        System.out.println("Please Press 2 To View Users");
        System.out.println("Please Press 3 To Modify User");
        System.out.println("Please Press 4 To Delete User");
        System.out.println("Please Press -1 To Log Out");

        AdminServiceImplementation adminService = new AdminServiceImplementation();

        String choice = StartUI.getInputFromBufferedReader();

        switch (choice) {
            case "1":
                addUser(adminService);
                break;
            case "2":
                viewUsers(adminService);
                break;
            case "3":
                modifyUser(adminService);
                break;
            case "4":
                deleteUserFromDatabase(adminService);
                break;
            case "-1":
                return;

            default:
                System.out.println("Please Enter A Valid Input.");
        }
        loginAsAdmin(loggedInUser);
    }

    // =========================================================
    // =                 Admin Functionality                   =
    // =========================================================

    //  1.1 - Adding User
    private static void addUser(AdminServiceImplementation adminService) {

        System.out.println("***** Adding Users To Database *****\n");

        /*
         * Get Name, Username, Password, UserGrade From User
         */

        System.out.println("Enter Full Name");
        String name = StartUI.getAValidNameFromUser("Enter A Valid Name");

        System.out.println("Enter Username");

        String username = StartUI.getInputFromBufferedReader();

        System.out.println("Enter Password");

        String password = StartUI.getInputFromBufferedReader();

        int userGrade = getAValidUserGradeFromUser("Enter A Valid User Grade");

        /*
         * Creating User Object To Be Passed Further
         */

        User.Builder builder = new User.Builder();
        builder.username(username).password(password).userGrade(userGrade).name(name);
        User userToBeAdded = builder.build();

        /*
         * Calling The AddUser() method and Getting Its Return Status
         */

        boolean status = adminService.addUser(userToBeAdded);

        //Printing Out Relevant Message
        if (status) {
            System.out.println("User Added Successfully");
        } else {
            System.out.println("Failed To Add User");
        }
    }

    private static int getAValidUserGradeFromUser(String message) {
        // While User Grade is not in Range 101 To 103

        System.out.println("Enter User Grade");
        System.out.println("101 For Resource Manager");
        System.out.println("102 For Executive");
        System.out.println("103 For Admin");

        int userGradeID = StartUI.getAValidNumberFromUser(message);
        while (!(userGradeID <= IRSValues.ADMIN && userGradeID >= IRSValues.RESOURCE_MANAGER)) {
            System.out.println("Enter A Valid User Grade");
            userGradeID = StartUI.getAValidNumberFromUser(message);
        }
        return userGradeID;
    }

    //  1.2 - Viewing Users
    private static void viewUsers(AdminServiceImplementation adminService) {

        System.out.println("***** Viewing Users In Database *****");
        ArrayList<User> usersInDatabase = adminService.viewUsers();

        for (User user : usersInDatabase) {
            System.out.print(
                    "{ Name : " + user.getName() + ", " +
                            " Grade : " + user.getUserGrade() + ", " +
                            " User ID : " + user.getUserID() + " }\n");
        }
        System.out.println();
    }

    //  1.3 - Modify User
    private static void modifyUser(AdminServiceImplementation adminService) {

        System.out.println("***** Modifying A User, Start With Entering the user ID *****");

        int userID = StartUI.getAValidNumberFromUser("Enter User In Correct Format");

        System.out.println("Enter The New Name");
        String name = StartUI.getAValidNameFromUser("Enter A Valid Name For User");

        System.out.println("Enter The New UserName");
        //StartUI.inputScanner.next();
        String username = StartUI.getInputFromBufferedReader();
        System.out.println("Got " + username);

        System.out.println("Enter The New Password");
        String password = StartUI.getInputFromBufferedReader();
        System.out.println("Got " + username);

        int userGrade = getAValidUserGradeFromUser("New User Grade Must Be A Valid Username");

        User.Builder builder = new User.Builder();
        builder.userID(userID).name(name).username(username).password(password).userGrade(userGrade);
        User userToBeModified = builder.build();

        boolean status = adminService.modifyUser(userToBeModified);

        //Printing Out Relevant Message
        if (status) {
            System.out.println("User Modified Successfully");
        } else {
            System.out.println("Failed To Modify User, No Changes Were Saved");
        }
    }

    //  1.4 - Delete User
    private static void deleteUserFromDatabase(AdminServiceImplementation adminService) {

        System.out.println("***** Delete An Existing User *****");

        System.out.println("Existing Users : ");
        viewUsers(adminService);

        System.out.println("Enter User ID Of User To Be Deleted");

        int userID = StartUI.getAValidNumberFromUser("This doesn't look like a UserId");

        User.Builder builder = new User.Builder();
        builder.userID(userID);
        User userToBeDeleted = builder.build();

        boolean status = adminService.deleteUser(userToBeDeleted);

        //Printing Out Relevant Message
        if (status) {
            System.out.println("User Deleted Successfully");
        } else {
            System.out.println("Failed To Delete User, Maybe the User doesn't exists?");
        }
    }

}
