package com.demo.UI;

import com.demo.Model.User;
import com.demo.Service.Implementation.UserServiceImplementation;
import com.demo.Util.DBUtil;
import com.demo.Util.IRSValues;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.Scanner;

public class StartUI {

    //	Main Method Method
    final public static void main(String[] args) {

        User.Builder builder = new User.Builder();
        //builder.username("div96").password("timi123").userID(522).name("Divya Verma");
      /*  builder.username("dhiraj").password("dhiraj").userID(1134).name("Dhiraj Trivedi");
        builder.username("DJ").password("DJ").userID(199).name("Dhananjay Trivedi");
        User user = builder.build();
*/
        //loginAsExecutive(user);
        //loginAsResourceManager(user);
//        AdminUI.loginAsAdmin(user);

        startTheProgram();

    }

    //	Start The Program Method
    private static void startTheProgram() {

        printSymbols();
        System.out.println("Welcome To Internal Recruitment System");
        System.out.println("Press 1. To Login");
        System.out.println("Press 2. To Exit");

        String userInput = getInputFromBufferedReader();

        switch (userInput) {

            // Login The User
            case "1":
                loginUser();
                break;

            //  Else, Exit Program
            case "2":
                System.out.println("Have a great day!");
                //Closing Any Database Connection If Opened By Program
                DBUtil.getInstance().closeConnection();
                System.exit(0);
        }
        startTheProgram();
    }

    //	Login user Method
    private static void loginUser() {

        // This part of code asks for user credentials and processes it for validation

        System.out.println("Enter Your Credentials");
        System.out.println("Enter -1 To Go Back");
        System.out.println("Username : ");

        String username = getInputFromBufferedReader();

        // If user wants to go back
        if (username.equals("-1")) {
            return;
        }

        /*
         * Else, proceed with Login.
         */

        System.out.println("Password : ");
        String password = getInputFromBufferedReader();

        /*
         * Creating User Object For Login.
         */

        User.Builder builder = new User.Builder();
        builder.username(username).password(password);
        User newUser = builder.build();

        /*
         * Getting LoggedInUser Object Back From Database,
         * Which contains validation information.
         */

        User loggedInUser = checkUserCredentials(newUser);

        /*
         * Checking User Grade (User Access) And Logging-In User Further According To Their Grade.
         */

        if (loggedInUser.isValidUser()) {
            int userGrade = loggedInUser.getUserGrade();
            switch (userGrade) {

                case IRSValues.ADMIN:
                    System.out.println("Logging In As Admin");
                    AdminUI.loginAsAdmin(loggedInUser);
                    break;

                case IRSValues.EXECUTIVE:
                    System.out.println("Logging In As Executive");
                    ExecutiveUI.loginAsExecutive(loggedInUser);
                    break;

                case IRSValues.RESOURCE_MANAGER:
                    System.out.println("Logging In As Manager");
                    ManagerUI.loginAsResourceManager(loggedInUser);
                    break;

                default:
                    System.out.println("Invalid User Login");
                    break;
            }
        } else {
            System.out.println("Invalid Credentials");
            loginUser();
        }

    }

    // =========================================================
    // =                  Login User Methods                   =
    // =========================================================

    private static User checkUserCredentials(User newUser) {

        UserServiceImplementation userService = new UserServiceImplementation();
        User loggedInUser = userService.loginUser(newUser);
        return loggedInUser;
    }


    // =========================================
    // =                                       =
    // =         Other Support Methods         =
    // =                                       =
    // =========================================

    //	Greet Symbols
    static void printSymbols() {
        System.out.println("\n\n\n\n=====================================================");
    }

    // Print Spaces
    static void printSpaces() {
        System.out.println();
    }

    //	Greet User
    static void greetUser(User loggedInUser) {
        System.out.println("Welcome " + loggedInUser.getName() + ", ");
    }


    static int getAValidNumberFromUser(String message) {
        String inputNumberAsString = getInputFromBufferedReader();

        while (!inputNumberAsString.matches("[-]?[0-9]+")) {
            System.out.println(message);
            inputNumberAsString = getInputFromBufferedReader();
        }
        return Integer.valueOf(inputNumberAsString);
    }

    static String getAValidStringFromUser(String message) {
        String userInput = getInputFromBufferedReader();

        while (!userInput.matches("[a-zA-Z]+$")) {
            System.out.println(message + "From here");
            userInput = getInputFromBufferedReader();
        }
        return userInput;
    }

    static String getAValidNameFromUser(String message) {
        String userInput = getInputFromBufferedReader();
        while (!userInput.matches("[a-zA-Z]*[\\s]?[a-zA-Z]*")) {
            System.out.println(message);
            userInput = getInputFromBufferedReader();
        }
        return userInput;
    }

    static String getInputFromBufferedReader() {
        BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
        try {
            String userInput = br.readLine();
            return userInput.trim();
        } catch (IOException e) {
            System.out.println("Exception Occurred While Taking Input From User");
        }
        return getInputFromBufferedReader().trim();
    }

}
