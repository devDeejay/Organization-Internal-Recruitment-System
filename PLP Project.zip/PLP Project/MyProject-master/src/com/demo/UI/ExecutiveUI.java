package com.demo.UI;

import com.demo.Model.Employee;
import com.demo.Model.RequisitionRequest;
import com.demo.Model.User;
import com.demo.Service.Implementation.ExecutiveServiceImplementation;
import com.demo.Util.IRSValues;

import java.sql.Date;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Iterator;


public class ExecutiveUI {

    // ===================================================================
    // =                                                                 =
    // =          2. When User is Logged In As Resource Manager          =
    // =                                                                 =
    // ===================================================================

    static void loginAsExecutive(User loggedInUser) {

        StartUI.printSymbols();

        StartUI.greetUser(loggedInUser);
        int executiveID = loggedInUser.getUserID();

        System.out.println("Please Press 1 To Search Employee");
        System.out.println("Please Press 2 To Assign Project To Manager");
        System.out.println("Please Press 3 To View All Requisition Requests");
        System.out.println("Please Press 4 To Generate Reports");
        System.out.println("Please Press 5 To Suggest For Requests");
        System.out.println("Please Press -1 To Logout");

        ExecutiveServiceImplementation executiveService = new ExecutiveServiceImplementation();

        String rmgInput = StartUI.getInputFromBufferedReader();

        switch (rmgInput) {
            case "1":
                //  TODO : Search Employee On Domain / Skill / Experience / ID.
                searchEmployee(executiveService);
                break;

            case "2":
                //  TODO : Assign RMG Project To Employee.
                assignProjectToRM(executiveService, executiveID);
                break;

            case "3":
                //  TODO : View All Requisition Requests.
                viewAllRequisitionRequests(executiveService, executiveID);
                break;

            case "4":
                //  TODO : Generate Reports For Closed / Pending Requests from all Resource Managers for specific Date / Time / Closed / Pending.
                generateReports(executiveService, executiveID);
                break;

            case "5":
                //  TODO : Generate Suggestions.
                giveSuggestionForRequest(executiveService, executiveID);
                break;

            case "-1":
                return;

            default:
                System.out.println("Incorrect Input, Try Again");
                loginAsExecutive(loggedInUser);
        }
        loginAsExecutive(loggedInUser);
    }

    // ================================================================
    // =      				RMG Executive Methods     				  =
    // ================================================================

    //  3.1 - Search Employee

    private static void searchEmployee(ExecutiveServiceImplementation executiveService) {

        System.out.println("Press 1 To Search By ID");
        System.out.println("Press 2 To Search By Domain");
        System.out.println("Press 3 To Search By Experience");
        System.out.println("Press 4 To Search By Skills");
        System.out.println("Press -1 To Go Back To Previous Menu");

        String executiveInput = StartUI.getInputFromBufferedReader();

        switch (executiveInput) {

            case "1":
                searchEmployeeByID(executiveService);
                break;

            case "2":
                searchEmployeeByDomain(executiveService);
                break;

            case "3":
                searchEmployeeByExperience(executiveService);
                break;

            case "4":
                searchEmployeeBySkills(executiveService);
                break;

            case "-1":
                return;

            default:
                System.out.println("Please enter valid input");
                break;
        }
        searchEmployee(executiveService);
    }

    private static void searchEmployeeBySkills(ExecutiveServiceImplementation executiveService) {
        String skills = StartUI.getInputFromBufferedReader();
        executiveService.searchEmployeeBySkills(skills);
    }

    private static void searchEmployeeByExperience(ExecutiveServiceImplementation executiveService) {
        System.out.println("Enter The Minimum Number Of Years of Experience");
        System.out.println("Enter -1 To Go Back");
        String experience = StartUI.getInputFromBufferedReader();

        while (!experience.matches("[0-9]+")) {
            System.out.println("Please Give A Valid Number");
            experience = StartUI.getInputFromBufferedReader();
            if (experience.equals("-1")) {
                return;
            }
        }
        int yearsOfExperience = Integer.parseInt(experience);

        executiveService.searchEmployeeByExperience(yearsOfExperience);
    }

    //  3.1.1 - Search Employee By Domain
    private static void searchEmployeeByDomain(ExecutiveServiceImplementation executiveService) {

        System.out.println("Enter The Domain Of Employee");
        System.out.println("Enter -1 To Go Back");

        String domainName = StartUI.getInputFromBufferedReader();
        if (domainName.equals("-1")) {
            return;
        }
        while (!domainName.matches("[a-zA-Z]+$")) {
            System.out.println("Please Enter A Valid Domain Name");

            domainName = StartUI.getInputFromBufferedReader();
        }

        String domain = StartUI.getAValidStringFromUser("Enter A Valid Domain");
        ArrayList<Employee> listOfEmployees = executiveService.searchEmployeeByDomain(domain);

        Iterator<Employee> iterator = listOfEmployees.iterator();

        while (iterator.hasNext()) {
            Employee e = iterator.next();
            printEmployeeObject(e);
        }
    }

    //  3.1.2 - Search Employee By ID
    private static void searchEmployeeByID(ExecutiveServiceImplementation executiveService) {

        System.out.println("Enter Employee ID To Be Searched");
        System.out.println("Enter -1 To Go Back");

        Employee e = null;
        int ID = StartUI.getAValidNumberFromUser("Enter A Valid Employee ID");
        if (ID > 0) {
            e = executiveService.searchEmployeeByID(ID);
            System.out.println("YO" + e.getEmployeeDomain());
        }
        System.out.println("I am here with " + e.getEmployeeName());

        if (e != null) {
            printEmployeeObject(e);
        } else {
            System.out.println("Employee not found in the database.");
        }
    }

    //  3.2 - Assign Project To Employee
    private static void assignProjectToRM(ExecutiveServiceImplementation executiveService, int executiveID) {

        System.out.println("Assign Project To Employee");

        // Executive Can Allocate Employees For Projects
        // Of only which they are in charge of

        System.out.println("Enter The Project ID");
        int projectID = StartUI.getAValidNumberFromUser("Enter Valid Project ID");
        System.out.println("Enter The Employee ID");
        int employeeID = StartUI.getAValidNumberFromUser("Enter Valid Employee ID");

        //TODO : Allocate the project
        boolean status = executiveService.assignProjectToEmployee(projectID, employeeID, executiveID);
        if (status) {
            System.out.println("Records Updated Successfully");
        } else {
            System.out.println("Records Not Updated Successfully");
        }
    }

    //  3.2 - View All Requests
    private static void viewAllRequisitionRequests(ExecutiveServiceImplementation executiveService, int executiveID) {
        getRequest(executiveService, executiveID, IRSValues.REQUISITION_REQUEST_OPEN);
    }

    //  3.3 - Give Suggestion On Basis Of Requests
    private static void giveSuggestionForRequest(ExecutiveServiceImplementation executiveService, int executiveID) {
        System.out.println("Display Open Requests");
        System.out.println("Enter -1 To Go Back");

        // SHOW OPEN REQUESTS
        getRequest(executiveService, executiveID, IRSValues.REQUISITION_REQUEST_OPEN);

        System.out.println("Enter The Request ID For which you want to suggest");

        int requisitionRequestID = StartUI.getAValidNumberFromUser("Enter A Correct Requisition Request");

        System.out.println("Enter 1. If You want to search employees");
        String choice = StartUI.getInputFromBufferedReader();
        if (choice.equals("1")) {

            // SEARCH EMPLOYEES

            searchEmployee(executiveService);
        }

        System.out.println("Enter the Employee For 2 Employees ");

        int emp1ID = StartUI.getAValidNumberFromUser("Enter Correct ID For Employee 1");
        int emp2ID = StartUI.getAValidNumberFromUser("Enter Correct ID For Employee 2");

        String combinedEmployees = emp1ID + " " + emp2ID;

        boolean done = executiveService.giveSuggestion(executiveID, requisitionRequestID, combinedEmployees);

        if (done) {
            System.out.println("Suggestion Raised");
        } else {
            System.out.println("Suggestion Not Raised");
        }
    }

    //  3.4 - Generate Reports
    private static void generateReports(ExecutiveServiceImplementation executiveService, int executiveID) {

        System.out.println("Press 1 To Get All Closed Requests");
        System.out.println("Press 2 To Get All Closed Request By Some Date");
        System.out.println("Press 3 To Get All Open Request");
        System.out.println("Press 4 To Get All Open Request By Some Date");
        System.out.println("Press -1 To Go Back To Previous Section");

        String executiveInput = StartUI.getInputFromBufferedReader();
        Date date;
        switch (executiveInput) {
            case "1":
                getRequest(executiveService, executiveID, IRSValues.ALL_CLOSED_REQUESTS);
                break;

            case "2":
                date = getDateFromUserAndParseIt();
                getRequest(executiveService, executiveID, IRSValues.ALL_CLOSED_REQUESTS, date);
                break;

            case "3":
                getRequest(executiveService, executiveID, IRSValues.ALL_OPEN_REQUESTS);
                break;

            case "4":
                date = getDateFromUserAndParseIt();
                getRequest(executiveService, executiveID, IRSValues.ALL_OPEN_REQUESTS, date);
                break;

            case "-1":
                return;

            default:
                System.out.println("Invalid Input, Try Again");
                break;
        }
        generateReports(executiveService, executiveID);
    }

    private static Date getDateFromUserAndParseIt() {

        System.out.println("Enter Date In Format DD-MM-YYYY");
        String inputStringDate = StartUI.getInputFromBufferedReader();

        SimpleDateFormat format = new SimpleDateFormat("DD-MM-YYYY");
        java.util.Date parsedDate = null;
        java.sql.Date sqlDate = null;
        try {
            parsedDate = format.parse(inputStringDate);
            sqlDate = new java.sql.Date(parsedDate.getTime() + 86400000);
        } catch (ParseException e) {
            System.out.println("Invalid Date Format");
            e.printStackTrace();
        }
        return sqlDate;
    }

    private static void getRequest(ExecutiveServiceImplementation executiveService, int executiveID, int requestCode, Date date) {
        ArrayList<RequisitionRequest> listOfRequests = executiveService.viewAllRequisitionRequests(executiveID, requestCode, date);

        Iterator<RequisitionRequest> iterator = listOfRequests.iterator();

        while (iterator.hasNext()) {
            RequisitionRequest request = iterator.next();
            ManagerUI.printRequestObject(request);
        }
    }

    private static void getRequest(ExecutiveServiceImplementation executiveService, int executiveID, int requestCode) {
        ArrayList<RequisitionRequest> listOfRequests = executiveService.viewAllRequisitionRequests(
                executiveID,
                requestCode,
                new java.sql.Date(new java.util.Date(System.currentTimeMillis() + 86400000).getTime())
        );

        Iterator<RequisitionRequest> iterator = listOfRequests.iterator();

        while (iterator.hasNext()) {
            RequisitionRequest request = iterator.next();
            ManagerUI.printRequestObject(request);
        }
    }

    static void printEmployeeObject(Employee e) {

        /*
         * Checking For No Data
         */

        if (e == null) {
            System.out.println("No Data Found For The Employee");
            return;
        }

        /*
         * Else, Print Data
         */
        System.out.println("    Employee Details:");
        System.out.println("    {");
        System.out.println(
                "       ID : " + e.getEmployeeID() + ",\n" +
                        "       Name : " + e.getEmployeeName() + ",\n" +
                        "       Project ID : " + e.getEmployeeProjectID() + ",\n" +
                        "       Domain : " + e.getEmployeeDomain() + ",\n" +
                        "       Skills : " + e.getEmployeeSkills() + ",\n" +
                        "       Experience : " + e.getYearsOfExperience() + ",\n" +
                        "       Allocation Status : " + (e.getEmployeeStatus() == IRSValues.ALLOCATED_IN_PROJECT ? "Allocated" : "Unallocated") + "\n"
        );
        System.out.println("    }");
    }
}
