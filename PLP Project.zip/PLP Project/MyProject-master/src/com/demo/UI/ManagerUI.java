package com.demo.UI;

import com.demo.Model.RequisitionRequest;
import com.demo.Model.RequisitionSuggestions;
import com.demo.Model.User;
import com.demo.Service.Implementation.ExecutiveServiceImplementation;
import com.demo.Service.Implementation.ResouceManagerServiceImplementation;
import com.demo.Util.IRSValues;

import java.util.ArrayList;
import java.util.Iterator;

public class ManagerUI {

    static void loginAsResourceManager(User loggedInUser) {

        // ================================================================
        // =                                                              =
        // =          3. When User is Logged In As RMG Executive          =
        // =                                                              =
        // ================================================================

        StartUI.printSymbols();
        StartUI.greetUser(loggedInUser);
        int managerID = loggedInUser.getUserID();

        /*
         *
         * TODO : View All The Suggestions Made By ExecutiveDAOInterface.
         * TODO : Accept / Reject The Suggested Resources Against Requisitions.
         * TODO : Manually Update The Project Name, Code.
         * TODO : Generate Reports For Pending As Well As Closed Requests of his projects.
         */

        System.out.println("Press 1 To Raise New Requisition Request");
        System.out.println("Press 2 To See Executive Suggestions For " + loggedInUser.getName());
        System.out.println("Press 3 To Accept / Reject the Suggestions");
        System.out.println("Press 4 To Update Project Allocation For Employee");
        System.out.println("Press 5 To See Reports");
        System.out.println("Press -1 To Go Logout");

        ResouceManagerServiceImplementation resourceManagerService = new ResouceManagerServiceImplementation();

        String rmgInput = StartUI.getInputFromBufferedReader();

        switch (rmgInput) {
            case "1":
                raiseNewRequisitionRequest(resourceManagerService, managerID);
                break;

            case "2":
                viewExecutivesSuggestions(resourceManagerService, managerID);
                break;

            case "3":
                acceptRejectSuggestions(resourceManagerService, managerID);
                break;

            case "4":
                updateProjectAllocationForEmployee(resourceManagerService, managerID);
                break;

            case "5":
                generateReportsForResourceManager(resourceManagerService, loggedInUser);
                break;

            case "-1":
                return;

            default:
                System.out.println("Enter Valid Input, Please Try Again");
                break;
        }

        //Re-run This Menu
        loginAsResourceManager(loggedInUser);

    }

    // ====================================================================
    // =                  Resource Manager Functionality                  =
    // ====================================================================

    // 2.1 - Raise New Requisition Request - DONE - WORKING
    private static void raiseNewRequisitionRequest(ResouceManagerServiceImplementation resourceManagerService, int managerID) {

        /*
         * Get Vacancy, Skills, Domain, Number of Required People at moment
         */


        StartUI.printSymbols();
        System.out.println("***** Raising Requisition Request *****");

        System.out.println("Enter Vacancy Of People In Numbers");
        int vacancy = StartUI.getAValidNumberFromUser("Enter Valid Vacancy");
        if (vacancy < 0) {
            return;
        }

        System.out.println("Enter The Skills");
        String skills = StartUI.getInputFromBufferedReader().toLowerCase();

        // Capitalizing First Letter of Skill
        skills = skills.substring(0, 1).toUpperCase() + skills.substring(1);

        System.out.println("Enter Domain Name");
        String domainName = StartUI.getAValidStringFromUser("Enter A Valid Domain Name");

        System.out.println("Enter Number Of People Required");
        int numberOfPeopleRequired = StartUI.getAValidNumberFromUser("Enter A Valid Number Of Required People");

        // Building The Requisition Request Object
        RequisitionRequest.Builder builder = new RequisitionRequest.Builder();
        builder
                .resourceManagerID(managerID)
                .vacancy(vacancy)
                .skillsAsString(skills)
                .domainName(domainName)
                .numberOfPeopleRequired(numberOfPeopleRequired);

        RequisitionRequest newRequisitionRequest = builder.build();

        // Calling Service Layer For Processing
        int requisitionRequestID = resourceManagerService.raiseRequisitionRequest(newRequisitionRequest);

        // Checking For Returning Values
        if (requisitionRequestID != 0) {
            System.out.println("Requisition Request Raised");
        } else {
            System.out.println("Failed To Raise Requisition Request");
        }
    }

    // 2.2 - View Suggestion Made By Executives - DONE
    private static void viewExecutivesSuggestions(ResouceManagerServiceImplementation resourceManagerService, int managerID) {

        System.out.println("***** View Executive Suggestions *****");
        System.out.println(
                "Enter 1. To View All OPEN suggestions\n" +
                        "Enter 2. To View All ACCEPTED suggestions\n" +
                        "Enter 3. To View All REJECTED suggestions\n" +
                        "Enter 4. To View All suggestions\n" +
                        "Enter -1 To Go Back"
        );

        String inputCase = StartUI.getInputFromBufferedReader();
        switch (inputCase) {
            case "1":

                // ================================================================
                // =      			List Of All Open Suggestions     		      =
                // ================================================================

                System.out.println("<<-- ALL OPEN SUGGESTIONS -->>");
                showSuggestion(resourceManagerService, managerID, IRSValues.ALL_OPEN_SUGGESTIONS);
                break;

            case "2":

                // ================================================================
                // =      		    List Of All Accepted Suggestions     		  =
                // ================================================================

                System.out.println("<<-- ALL ACCEPTED SUGGESTIONS -->>");
                showSuggestion(resourceManagerService, managerID, IRSValues.ALL_ACCEPTED_SUGGESTIONS);
                break;

            case "3":

                // ================================================================
                // =      		    List Of All Rejected Suggestions     		  =
                // ================================================================

                System.out.println("<<-- ALL REJECTED SUGGESTIONS -->>");
                showSuggestion(resourceManagerService, managerID, IRSValues.ALL_REJECTED_SUGGESTIONS);
                break;

            case "4":

                // ================================================================
                // =      				List Of All Suggestions     			  =
                // ================================================================

                System.out.println("ALL SUGGESTIONS");
                showSuggestion(resourceManagerService, managerID, IRSValues.ALL_SUGGESTIONS);
                break;

            case "-1":
                // Going Back To Login As Manager
                return;

            default:
                System.out.println("Please Enter A Valid Input");
        }

        viewExecutivesSuggestions(resourceManagerService, managerID);

    }

    // 2.3 - Accept / Reject Suggestions Made By Executives - DONE
    private static void acceptRejectSuggestions(ResouceManagerServiceImplementation resourceManagerService, int managerID) {

        System.out.println("Accept / Reject Suggestions, You have the following suggestions");
        viewExecutivesSuggestions(resourceManagerService, managerID);

        System.out.println("Enter The Requisition Suggestion ID You Want To Accept / Reject ");
        int requisitionSuggestionID = StartUI.getAValidNumberFromUser("Enter Correct Requisition Suggestion ID");

        System.out.println("Please Enter 400 to Accept\n402 to Reject The Suggestion");
        int choice = StartUI.getAValidNumberFromUser("Enter Correct Choice");

        // Calling The Service Layer, Passing The Option, Getting  A Boolean in return if executed successfully
        if (resourceManagerService.acceptRejectSuggestions(managerID, requisitionSuggestionID, choice)) {
            if (choice == IRSValues.REQUISITION_SUGGESTION_ACCEPTED) {
                System.out.println("Suggestion Accepted");
            } else if (choice == IRSValues.REQUISITION_SUGGESTION_REJECTED) {
                System.out.println("Suggestion Declined");
            }
        }
    }

    // 2.4 - Update Project Allocation For Employee - DONE - WORKING
    private static void updateProjectAllocationForEmployee(ResouceManagerServiceImplementation resourceManagerService, int managerID) {

        System.out.println("*****   Updating Project Allocation For Employee    *****");
        System.out.println("Enter EmployeeID");
        int empID = StartUI.getAValidNumberFromUser("Enter A Valid Employee ID");

        System.out.println("Enter Project ID");
        System.out.println("Enter 0 For No Project");
        int projectID = StartUI.getAValidNumberFromUser("Enter A Valid Project ID");

        if (resourceManagerService.updateProjectForEmployee(managerID, empID, projectID)) {
            System.out.println("Details Updated Successfully");
        } else {
            System.out.println("Failed To Update Any Details");
        }
    }

    // 2.6 - Generate Reports For Resource Manager - DONE - PARTIALLY WORKING
    private static void generateReportsForResourceManager(ResouceManagerServiceImplementation resourceManagerService, User loggedInManager) {

        System.out.println("***********************************************************");
        System.out.println("    Request Raised By " + loggedInManager.getName());
        System.out.println("***********************************************************");

        // ================================================================
        // =      			List Of All Open Requests     				  =
        // ================================================================

        StartUI.printSpaces();
        System.out.println("*******   ALL OPEN REQUESTS   *******");
        showRequests(resourceManagerService, loggedInManager.getUserID(), IRSValues.REQUISITION_REQUEST_OPEN);

        // ================================================================
        // =      			List Of All Closed Requests     		      =
        // ================================================================

        StartUI.printSpaces();
        System.out.println("*******     ALL CLOSED REQUESTS   *******");
        showRequests(resourceManagerService, loggedInManager.getUserID(), IRSValues.REQUISITION_REQUEST_CLOSED);

    }

    // 2.6.1 Show Requests According to Type - DONE
    private static void showRequests(ResouceManagerServiceImplementation resourceManagerService, int managerID, int requestCode) {
        getAndDisplayRequests(resourceManagerService, managerID, requestCode);
    }

    // 2.6.2 Show Suggestions According to Type - DONE
    private static void showSuggestion(ResouceManagerServiceImplementation resourceManagerService, int managerID, int suggestionsCode) {

        ArrayList<RequisitionSuggestions> requisitionSuggestions = resourceManagerService.viewSuggestionsMadeByExecutive(managerID, suggestionsCode);

        // Checking If No Data is Fetched
        if (requisitionSuggestions == null) {
            System.out.println("No Suggestions Found In Database");
            return;
        }

        Iterator<RequisitionSuggestions> iterator = requisitionSuggestions.iterator();
        System.out.println("        {");
        while (iterator.hasNext()) {
            RequisitionSuggestions suggestion = iterator.next();
            System.out.println("\n" +
                    "           Suggestion ID : " + suggestion.getRequisitionSuggestionID() + ",\n" +
                    "           For Project ID : " + suggestion.getSuggestedProjectID() + ",\n" +
                    "           Suggested Employee ID : " + suggestion.getSuggestedEmployeeID() + "\n"
            );
            String[] listOfEmployee = suggestion.getSuggestedEmployeeID().split(" ");
            ExecutiveServiceImplementation executiveServiceImplementation = new ExecutiveServiceImplementation();
            for (int i = 0; i < listOfEmployee.length; i++) {
                ExecutiveUI.printEmployeeObject(executiveServiceImplementation.searchEmployeeByID(Integer.valueOf(listOfEmployee[i])));
            }
        }
        System.out.println("        }");
    }

    // 2.6.3 Support Method For Manager Functionality
    private static void getAndDisplayRequests(ResouceManagerServiceImplementation resourceManagerService, int managerID, int requestCode) {

        ArrayList<RequisitionRequest> listOfAllRequests = resourceManagerService.viewAllRequests(managerID, requestCode);

        if (listOfAllRequests == null) {
            System.out.println("No Records Found");
            return;
        }

        // Calling Printing Method For This Request Object

        Iterator<RequisitionRequest> iterator = listOfAllRequests.iterator();
        while (iterator.hasNext()) {
            RequisitionRequest request = iterator.next();
            printRequestObject(request);
        }
    }

    // 2.6.4 Support Method For Manager Functionality
    static void printRequestObject(RequisitionRequest request) {
        System.out.println("[ Request " + request.getRequsitionID() + " ]");

        System.out.println("   { \n" +
                "   Domain Name : " + request.getDomainName() + ",\n" +
                "	Project ID : " + request.getProjectID() + ",\n" +
                "	Vacancy Of People : " + request.getVacancy() + ",\n" +
                "	Required People : " + request.getNumberOfPeopleRequired() + ",\n" +
                "	Skills Required : " + request.getSkillsAsString() + ",\n" +
                "	Request Status : " + request.getRequestStatus() + ",\n" +
                "	Request Open Date : " + request.getDateCreated() + ",\n" +
                "	Request Close Date : " + request.getDateClosed() + "\n   }"
        );
    }


}
