-- Creating User Table

	CREATE TABLE users_table (
		user_id NUMBER(10),
		user_grade NUMBER(3) NOT NULL,
		username VARCHAR2(30) NOT NULL,
		userpassword VARCHAR2(30) NOT NULL,
		name VARCHAR2(30),
		CONSTRAINT unique_constraint UNIQUE (username),
		CONSTRAINT user_id PRIMARY KEY (user_id)
	);
    
    CREATE SEQUENCE user_id_generator
        MINVALUE 500
        MAXVALUE 99999
        START WITH 500
        INCREMENT BY 1;
    
    -- Insertion Queries
    
        INSERT INTO users_table VALUES(
            0,
            104,
            'null',
            'null',
            'null'
        );
    
        INSERT INTO users_table VALUES(
            2134,
            101,
            'deejay',
            'deejay',
            'Dhananjay Trivedi'
        );

        INSERT INTO users_table VALUES(
            1134,
            101,
            'dhiraj',
            'dhiraj',
            'Dhiraj Trivedi'
        );

        INSERT INTO users_table VALUES(
            11230,
            101,
            'anjali',
            'anjali',
            'Anjali Trivedi'
        );

        INSERT INTO users_table VALUES(
            3133,
            102,
            'ayush',
            'ayush',
            'Ayush Singh'
        );
        
        INSERT INTO users_table VALUES(
            1320,
            102,
            'Divya',
            'Divya',
            'Divya Verma'
        );

        INSERT INTO users_table VALUES(
            6133,
            103,
            'utkarsh',
            'utkarsh',
            'Utkarsh Singh'
        );
    
    -- Updating User Table
        
    UPDATE users_table
        SET 
            user_grade = 103,
            username = 'Utk',
            userpassword = 'Utk',
            name = 'Utkarshyy'
        WHERE user_id > 6133;

-- Creating Project Table

	CREATE TABLE project_table (
		project_id NUMBER(10),
		project_name VARCHAR2(30) NOT NULL,
		project_manager_id NUMBER(10) REFERENCES users_table(user_id),
        executive_ID NUMBER(10) REFERENCES users_table(user_id),
        project_start_date DATE,
        project_end_date DATE,
		CONSTRAINT project_id PRIMARY KEY (project_id),
		CONSTRAINT project_name_constraint UNIQUE (project_name)
	);

    -- Insertion Queries 2 Projects
    
        INSERT INTO project_table(
            project_id,
            project_name,
            project_manager_id,
            executive_ID,
            project_start_date
        )
        VALUES(
            8036,
            'Android Project',
            1134,
            3133,
            SYSDATE
        );

        INSERT INTO project_table(
            project_id,
            project_name,
            project_manager_id,
            executive_ID,
            project_start_date
        )
        VALUES(
            1112,
            'Java Project',
            2134,
            1320,
            SYSDATE
        );
        
        
        INSERT INTO project_table(
            project_id,
            project_name,
            project_manager_id,
            executive_ID,
            project_start_date
        )
        VALUES(
            9212,
            'Angular Project',
            1134,
            522,
            SYSDATE
        );
        
         INSERT INTO project_table(
            project_id,
            project_name,
            project_manager_id,
            executive_ID,
            project_start_date
        )
        VALUES(
            9212,
            'Angular Project',
            1134,
            522,
            SYSDATE
        );
        
         INSERT INTO project_table(
            project_id,
            project_name,
            project_manager_id,
            executive_ID,
            project_start_date
        )
        VALUES(
            0,
            'No Allocated Project',
            0,
            0,
            SYSDATE
        );

-- Creating Employee Table

	CREATE TABLE employee_table (
		emp_id NUMBER(10),
		emp_project_id NUMBER(10) REFERENCES project_table(project_id),
        emp_name VARCHAR2(100),
		emp_allocation_status NUMBER(3),
		emp_experience_years NUMBER(2),
		emp_skills VARCHAR2(4000),
        emp_domain VARCHAR2(200),
        emp_join_date DATE,
		CONSTRAINT emp_id_constraint PRIMARY KEY (emp_id)
	);

    CREATE SEQUENCE emp_id_generator
        MINVALUE 1
        MAXVALUE 99999
        START WITH 1
        INCREMENT BY 1;
    
    INSERT INTO employee_table(
		emp_id,
		emp_project_id,
        emp_name,
		emp_allocation_status,
		emp_experience_years,
		emp_skills,
        emp_domain,
        emp_join_date
    ) VALUES (
        emp_id_generator.nextval,
        1112,
        'Dhananjay Trivedi',
        202,
        3,
        'Level 3',
        'Java',
        SYSDATE
    );

-- Requistion Suggestions

	CREATE TABLE requisition_suggestions_table (
		requisition_suggestion_id NUMBER(10),
		requisition_request_id NUMBER(10),
		suggested_project_id NUMBER(10) REFERENCES project_table(project_id),
		suggesting_executive_id NUMBER(10),
        requesting_manager_id NUMBER(10),
		suggested_employees VARCHAR2(1000),
		status_of_suggestion NUMBER(1),
        CONSTRAINT req_sgsid_const PRIMARY KEY (requisition_suggestion_id)
	);
    
    UPDATE requisition_suggestions_table SET status_of_suggestion = ? WHERE user_id = ?;
    

    CREATE SEQUENCE suggestions_id_generator
        MINVALUE 1
        MAXVALUE 99999
        START WITH 1
        INCREMENT BY 1;
    
-- Requistion Requests

	CREATE TABLE requisition_requests_table (
		requisition_request_id NUMBER(10),
		requesting_manager_id NUMBER(10),
		executiveID NUMBER(10),
		requesting_project_id NUMBER(10) REFERENCES project_table(project_id),
        request_status NUMBER(3),
		request_open_date DATE,
		request_close_date DATE,
		vacancy NUMBER(5),
		required NUMBER(5),
		skills_required VARCHAR2(4000),
		domain VARCHAR2(50),
		CONSTRAINT requisition_id_constraint PRIMARY KEY (requisition_request_id)
    );
    
    INSERT INTO requisition_requests_table (
        requisition_request_id,
        requesting_manager_id,
        requesting_project_id,
        request_status,
        request_open_date,
        vacancy,
        required,
        skills_required,
        domain,
        executiveID
    ) VALUES (
        requests_id_generator.nextval, ?, ?, ?, SYSDATE, ?, ?, ?, ?, ? )
    
    CREATE SEQUENCE requests_id_generator
        MINVALUE 1
        MAXVALUE 99999
        START WITH 1
        INCREMENT BY 1;
    
    INSERT INTO requisition_requests_table (
        requisition_request_id,
        requesting_manager_id,
        requesting_project_id,
        request_status,
        request_open_date,
        vacancy,
        required,
        skills_required,
        domain
    )
    VALUES (
        requests_id_generator.nextval,
        1134,
        2034,
        300,
        SYSDATE,
        10,
        2,
        'Java',
        'Java'
    );
    
    SELECT requests_id_generator.currval FROM DUAL;
    
    


